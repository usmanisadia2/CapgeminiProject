package com.capgemini.labwork;
//Create a method to find the sum of the cubes of the digits of an n digit number.

import java.util.Scanner;

public class Lab4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the digit");
		int n=sc.nextInt();
		int a,sum=0;
		while(n>0) {
			a=n%10;
			n=n/10;
			sum+=(a*a*a);	
		}
		System.out.println("The sum of cube of the digit is:"+sum);
		
	}

}
