package com.capgemini.labwork;

public class Lab9n1 {
	public static void main(String[] args) {
		Lab9n1fun r=(x,y) -> Math.pow(x,y);
		System.out.println(r.cal(2,4));
		System.out.println(r.cal(10, 3));
	}

}
