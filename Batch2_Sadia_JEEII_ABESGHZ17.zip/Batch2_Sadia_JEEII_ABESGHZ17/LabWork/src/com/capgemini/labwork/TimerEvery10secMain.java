package com.capgemini.labwork;

public class TimerEvery10secMain {

	public static void main(String[]args) {
		TimerEvery10sec t=new TimerEvery10sec();
       Thread th=new Thread(t);
       th.start();
	}
}
