package com.capgemini.labwork;

public interface Lab9n1fun {
	public double cal(int x,int y);

}
