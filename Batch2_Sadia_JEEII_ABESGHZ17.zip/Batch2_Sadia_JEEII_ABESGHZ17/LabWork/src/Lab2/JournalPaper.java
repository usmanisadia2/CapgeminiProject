package Lab2;

public class JournalPaper extends Item{
	private int year_publ;

@Override
public void checkIn() {
	// TODO Auto-generated method stub
	
}

@Override
public void checkOut() {
	// TODO Auto-generated method stub
	
}

@Override
public void addItem() {
	// TODO Auto-generated method stub
	
}
}

