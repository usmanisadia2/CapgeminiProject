package Lab2;

public class Control {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
