package Lab2;

public class Video extends MediaItem{
	private String director;
	private String genre;
	private int yearReleased;
	@Override
	public void checkIn() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		
	}
}

