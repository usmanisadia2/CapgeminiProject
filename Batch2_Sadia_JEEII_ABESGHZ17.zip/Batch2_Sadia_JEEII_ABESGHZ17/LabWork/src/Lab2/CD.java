package Lab2;

public class CD extends MediaItem{
	private String artist;
private String genre;
@Override
public void checkIn() {
	// TODO Auto-generated method stub
	
}
@Override
public void checkOut() {
	// TODO Auto-generated method stub
	
}
@Override
public void addItem() {
	// TODO Auto-generated method stub
	
}
}
