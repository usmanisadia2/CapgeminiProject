package Lab2;

public  abstract class MediaItem extends Item{
	private int runtime;
}
