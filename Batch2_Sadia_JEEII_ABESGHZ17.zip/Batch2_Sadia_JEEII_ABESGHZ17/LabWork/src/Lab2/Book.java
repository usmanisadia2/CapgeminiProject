package Lab2;


	public class Book extends Item{
		@Override
		public void checkIn() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void checkOut() {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void addItem() {
			// TODO Auto-generated method stub
			
		}

	
}


