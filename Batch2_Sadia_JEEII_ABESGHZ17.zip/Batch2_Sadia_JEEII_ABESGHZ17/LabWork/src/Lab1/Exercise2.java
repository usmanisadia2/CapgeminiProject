package Lab1;
//Create a class with a method to find the difference between the sum of the 
//squares and the square of the sum of the first n natural numbers.

import java.util.Scanner;
public class Exercise2 {
	public static void main(String args[]) {
		int n;
		System.out.println("Enter the number:");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		calculateDifference(n);
	}
	static int calculateDifference(int n) {
		int i,sum1=0,sum2=0;
		for(i=1;i<=n;i++) {
			sum1+=i;
		}
		sum1=sum1*sum1;
		for(i=1;i<=n;i++) {
			sum2=sum2+(i*i);
		}
		System.out.println("Result="+(sum2-sum1));
		return 0;
		}
}
