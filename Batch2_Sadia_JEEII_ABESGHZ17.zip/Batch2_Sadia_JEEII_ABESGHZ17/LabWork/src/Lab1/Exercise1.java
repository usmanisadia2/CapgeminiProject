package Lab1;

//Create a class with a method which can calculate the sum of
//first n natural numbers which are divisible by 3 or 5.
import java.util.Scanner;
public class Exercise1 {
	public static void main(String args[]) {
		int n;
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		calculateSum(n);
		}
	static int calculateSum(int n) {
		int i,sum=0;
		for(i=1;i<=n;i++) {
			if(i%3==0||i%5==0) {
				sum+=i;
			}
		}
		System.out.println("Sum="+sum);
		return 0;
	}

}
