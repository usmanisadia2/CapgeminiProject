package Lab1;
import java.lang.Math;
import java.util.Scanner;

//Create a method to check if a number is a power of two or not

public class Exercise4 {
	public static void main(String[] args) {
		int n;
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		checkNumber(n);
	}
	static int checkNumber(int n) {
		if(n==0) {
			System.out.println("False");
		}
		int count=0,i;
		for(i=1;i<100;i++) {
			if(Math.pow(2, i)==n)
				count++;
		}
		if(count!=0)
			System.out.println("True");
		else
			System.out.println("False");
		return 0;
	}

}
