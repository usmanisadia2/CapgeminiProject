package Lab1;
import java.util.Scanner;

//Create a method to check if a number is an increasing number

public class Exercise3 {
	public static void main(String [] args) {
		int number;
		boolean a=false;
		Scanner sc=new Scanner(System.in);
		number=sc.nextInt();
		int currentDigit=number%10;
		number=number/10;
		while(number>0) {
			if(currentDigit<=number%10) {
				a=true;
			}
			currentDigit=number%10;
			number=number/10;
		}
		if(a) {
			System.out.println("Digits are non-increasing");
		}
		else {
			System.out.println("Digits are increasing");
		}
																																																																	}

}
