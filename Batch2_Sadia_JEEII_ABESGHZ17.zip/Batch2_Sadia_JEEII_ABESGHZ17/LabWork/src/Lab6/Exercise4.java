package Lab6;

import java.util.Scanner;
import java.util.*;
//Create a method which accepts a String and replaces all the consonants in the String 
//with the next alphabet.
public class Exercise4 {
	static String alterString(String str) {
		StringBuffer sb=new StringBuffer(str);
		for(int i=0;i<str.length();i++) {
			if((str.charAt(i)=='A')||(str.charAt(i)=='E')||(str.charAt(i)=='I')||(str.charAt(i)=='O')
					||(str.charAt(i)=='U')||(str.charAt(i)=='a')||(str.charAt(i)=='e')||(str.charAt(i)=='i')
					||(str.charAt(i)=='o')||(str.charAt(i)=='u')) {
						
				     sb.append(str.charAt(i));
			}
			else
			{
				sb.append(str.charAt(i)+1);
			}
			
		}
		return str;
		
	}
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String str=sc.next();
		Exercise4.alterString(str);
	}

}
