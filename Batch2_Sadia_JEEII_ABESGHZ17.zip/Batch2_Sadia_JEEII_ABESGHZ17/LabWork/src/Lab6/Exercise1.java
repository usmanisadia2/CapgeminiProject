package Lab6;
//Write a Java program that reads a line of integers and then displays each integer and 
//the sum of all integers. (Use StringTokenizer class)?

import java.util.Scanner;
import java.util.StringTokenizer;
public class Exercise1 {
	public static void main(String[] args) {
		System.out.println("Enter the string of integers with whitespacing");
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		StringTokenizer n=new StringTokenizer(str,"");
		int sum=0,n2;
		while(n.hasMoreTokens()) {
			String num=n.nextToken();
			System.out.println(num);
			n2=Integer.parseInt(num);
			sum=sum+n2;
		}
		System.out.println("The sum is="+sum);
		
		
	}

}
