package Lab6;
import java.util.Scanner;

//Create a class containing a method to create the mirror image of a String. The 
//method should return the two Strings separated with a pipe(|) symbol .

public class Exercise3 {
	static void getImage(String str) {
		StringBuffer str1=new StringBuffer();
		str1.append(str);
		System.out.println(str1+"|"+str1.reverse());
		}
		public static void main(String args[]) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the string");
			String str=sc.nextLine();
			Exercise3.getImage(str);
		}
}
