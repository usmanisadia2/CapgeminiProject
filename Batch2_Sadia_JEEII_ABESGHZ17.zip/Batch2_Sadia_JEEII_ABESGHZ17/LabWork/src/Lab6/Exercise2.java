package Lab6;
//Write a Java program that reads a file and displays the file on the screen, with a line 
//number before each line?

import java.io.FileInputStream;
import java.io.IOException;

public class Exercise2 {
	public static void main(String[] args) throws IOException{
		FileInputStream f1=new FileInputStream("E:\\CapGemini Training\\SprintSql");
		int i=0,count=1;
		System.out.print("1"+"");
		while((i=f1.read())!=-1) {
			System.out.print((char)i);
			String.valueOf(i);
			if(i=='\n') {
				System.out.println();
				count++;
				System.out.print(count+"");
			}
		}
		f1.close();
		
	}

}
