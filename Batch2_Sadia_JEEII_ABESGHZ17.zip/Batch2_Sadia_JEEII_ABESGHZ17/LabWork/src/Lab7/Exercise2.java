package Lab7;

import java.util.*;
//Create a method that accepts a character array and count the number of times each 
//character is present in the array. Add how many times each character is present to a hash map 
//with the character as key and the repetitions count as value

public class Exercise2 {
	static Map<Character,Integer> countCharacter(Character[] arr){
		 HashMap<Character,Integer> map = new HashMap<>(); 
		 List<Character> list =Arrays.asList(arr);
		 int c=0;
		 for(Character ch:list) {
		  c=0;
		  c=Collections.frequency(list, ch);
		  map.put(ch, c);
		 }

		 return map;
		}
		public static void main(String[] args) {
		  Character a[]= {'a','p','p','l','e'};
		  System.out.println(countCharacter(a));
		  }

}
