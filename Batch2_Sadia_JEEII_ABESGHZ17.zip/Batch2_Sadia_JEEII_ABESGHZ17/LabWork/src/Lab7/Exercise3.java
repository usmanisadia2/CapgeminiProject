package Lab7;
import java.util.*;
//Create a method which accepts an array of numbers and returns the numbers and 
//their squares in HashMap

public class Exercise3 {
	static Map<Integer,Integer> getSquares(Integer arr[]){
		 HashMap<Integer,Integer> map=new HashMap<>();
		 List<Integer> list=Arrays.asList(arr);
		 for(Integer i:list) { 
			int value=i*i;
		    map.put(i, value);
		    }
		 return map;
		 }

		public static void main(String[] args){
			Integer arr[]= {1,2,3,4};
		    System.out.println(getSquares(arr));
		    }

}
