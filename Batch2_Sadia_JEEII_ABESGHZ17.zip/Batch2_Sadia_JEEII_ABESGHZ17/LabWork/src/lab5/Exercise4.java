package lab5;

import java.util.Scanner;

//Write a Java Program to validate the full name of an employee.
//Create and throw a user defined exception if firstName and lastName is blank
public class Exercise4 extends Exception {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first name");
		String s1=sc.nextLine();
		System.out.println("Enter the last name");
		String s2=sc.nextLine();
		Exercise4.validate(s1,s2);	
	}
	
	static void validate(String s1,String s2)
	{
		if((s1==null)||(s2==null)) {
			throw new NullPointerException("name is null");
		}
		else {
		System.out.println("THe name is valid,which is:"+s1+" "+s2);
	}
	}
	

}
